<?php
// 사용자가 제출한 값
$problemId = $_POST['id'] ?? '';
$userAnswer = $_POST['answer'] ?? '';

// 문제별 정답 배열 (문제 ID => 정답 배열)
$correctAnswers = [
    "1" => ["FLAG{UPLOAD}"],
    "2"  => ["FLAG{NOOB}"],
    "3"   => ["FLAG{XSS1}"],
    "4"   => ["FLAG{XSS2}"],
    "5"   => ["FLAG{LFI1}"],
    "6"   => ["FLAG{LFI2}"],
    "7"  => ["FLAG{SQLI1}"],
    "8"  => ["FLAG{SQLI2}"],
    "9"   => ["FLAG{RCE1}"],
    "10"   => ["FLAG{RCE2}"],
    "11"  => ["FLAG{NOOB3}"],
    "12"=> ["FLAG{UPLOAD3}"],
    "13"   => ["FLAG{XSS3}"],
    "14"   => ["FLAG{LFI3}"],
    "15"  => ["FLAG{SQLI3}"],
    "16"   => ["FLAG{RCE3}"],
    "17"  => ["FLAG{NOOB4}"],
    "18"=> ["FLAG{UPLOAD4}"],
    "19"   => ["FLAG{XSS4}"],
    "20"  => ["FLAG{FINAL}"]
];

// 문제 ID가 존재하고, 사용자가 제출한 정답이 해당 문제 정답 배열에 있는지 체크
if (isset($correctAnswers[$problemId]) && in_array($userAnswer, $correctAnswers[$problemId])) {

    // .done 파일 생성 (문제 풀림 기록)
    $done_file = __DIR__ . "/{$problemId}.done";
    file_put_contents($done_file, "solved");

    echo "<h1 style='color:green;'>정답입니다!</h1>";
} else {
    echo "<h1 style='color:red;'>오답입니다.</h1>";
}
?>

