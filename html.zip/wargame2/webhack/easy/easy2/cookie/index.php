<?php
if(!isset($_COOKIE['role'])) { setcookie('role','user'); $role='user'; }
else { $role=$_COOKIE['role']; }

if($role === 'admin'){
    echo "Next Password: FLAG{EASY2_DONE}";
} else {
    echo "User mode. Admin only.";
}
?>
