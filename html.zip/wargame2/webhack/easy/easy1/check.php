<?php
// 허용 가능한 정답 배열
$valid_answers = [
    "E-WORLD",
    "EWORLD",
    "e월드",
    "이월드",
    "e-월드",
    "이 월드",
    "E WORLD"
];

if (!isset($_POST['answer'])) {
    echo "입력값이 없습니다.";
    exit;
}

$input = trim(mb_strtolower($_POST['answer'])); // 대소문자 구분 없이 처리

// 다국어 비교를 위해 배열을 순회
$is_correct = false;
foreach ($valid_answers as $ans) {
    if ($input === mb_strtolower($ans)) {
        $is_correct = true;
        break;
    }
}

if ($is_correct) {
    echo "<span style='color:lime'>정답입니다!</span><br>FLAG{E WORLD pass}";
} else {
    echo "<span style='color:red'>틀렸습니다.</span>";
}
?>
