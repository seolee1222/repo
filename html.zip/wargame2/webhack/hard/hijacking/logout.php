<?php
session_start();

unset($_SESSION['user_id']);

// 5. 그냥 로그인 페이지만 보여줍니다.
header("Location: login.php");
exit;
?>
