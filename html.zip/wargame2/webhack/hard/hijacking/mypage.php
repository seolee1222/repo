<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$username = $_SESSION['user_id'];

// ▼▼▼ "admin"인지 확인하는 코드 추가 ▼▼▼
$flag_message = ""; // 기본값은 빈칸
if ($username === 'admin') {
    $flag_message = "🚩 FLAG{S3SSi0N_H1JACKing_SUcce55!!} 🚩";
}
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="utf-8">
    <title>마이페이지</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="wrap">
        <h1>마이페이지</h1>
        
        <p class="mypage-msg">
            환영합니다, <strong><?php echo htmlspecialchars($username); ?></strong> 님!
        </p>

        <?php if ($flag_message): ?>
            <div class="flag-box">
                <p>🎉 admin 권한 확인! 🎉</p>
                <p><?php echo $flag_message; ?></p>
            </div>
        <?php endif; ?>
        <a href="logout.php" class="logout-link">로그아웃</a>
    </div>
</body>
</html>
