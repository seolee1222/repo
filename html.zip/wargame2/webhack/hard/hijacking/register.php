<?php
session_start();
$message = "";
$msg_class = "error"; // 메시지 CSS 클래스

if (isset($_POST['register'])) {
    $id = $_POST['id'];
    $pw = $_POST['pw'];

    // ▼▼▼ 1. 'admin' 아이디 가입 차단 로직 (소문자 비교) ▼▼▼
    if (strtolower($id) === 'admin') {
        $message = "이 ID는 사용할 수 없습니다. 😥";
    }
    // ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲

    // 2. (통과되면) 기존 회원가입 로직 실행
    elseif (!empty($id) && !empty($pw)) {
        $_SESSION['registered_id'] = $id;
        $_SESSION['registered_pw'] = $pw;
        $message = "회원가입 성공! 🎉 로그인 페이지로 이동하세요.";
        $msg_class = "success"; 
    } else {
        $message = "ID와 PW를 모두 입력하세요. 🙄";
    }
}
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="utf-8">
    <title>회원가입</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="wrap">
        <h1>회원가입</h1>
        <form method="post">
            <input type="text" name="id" placeholder="사용할 ID" required>
            <input type="password" name="pw" placeholder="사용할 PW" required>
            <button type="submit" name="register">회원가입</button>
        </form>
        <?php if($message): ?>
            <p class="message <?php echo $msg_class; ?>">
                <?php echo $message; ?>
            </p>
        <?php endif; ?>
        <a href="login.php">로그인 페이지로 가기</a>
    </div>
</body>
</html>
