<?php
$cookie_data = "PHPSESSID=" . ($_COOKIE['PHPSESSID'] ?? 'NoCookie_Found');

file_put_contents('cookie_log.txt', $cookie_data);

echo "Bot visit processed.";
?>

<!--The bot is probably writing a cookie log file.-->

