<?php
session_start();
$message = "";

define('ADMIN_ID', 'admin');
define('ADMIN_PASSWORD', 'admin1234'); // 👈 어드민 비번!

if (isset($_POST['login'])) {
    $id = $_POST['id'];
    $pw = $_POST['pw'];

    if ($id === ADMIN_ID && $pw === ADMIN_PASSWORD) {
        $_SESSION['user_id'] = ADMIN_ID; // 'admin'으로 세션 저장
        header("Location: mypage.php");
        exit;
    }

    elseif (!isset($_SESSION['registered_id'])) {
        $message = "먼저 회원가입을 해주세요. 😢";
    } 
    elseif ($id === $_SESSION['registered_id'] && $pw === $_SESSION['registered_pw']) {
        $_SESSION['user_id'] = $_SESSION['registered_id'];
        header("Location: mypage.php");
        exit;
    } else {
        $message = "ID 또는 PW가 일치하지 않습니다. ❌";
    }
}
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="utf-8">
    <title>로그인</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="wrap">
        <h1>로그인</h1>
        <form method="post">
            <input type="text" name="id" placeholder="ID" required>
            <input type="password" name="pw" placeholder="PW" required>
            <button type="submit" name="login">로그인</button>
        </form>
        <?php if($message): ?>
            <p class="message error"><?php echo $message; ?></p>
        <?php endif; ?>
        <a href="register.php">회원가입 페이지로 가기</a>
    </div>
</body>
</html>
