<?php
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    if(!isset($_FILES['file'])){
        die("Upload failed");
    }

    $f    = $_FILES['file'];
    $name = $f['name'];
    $tmp  = $f['tmp_name'];
    $type = $f['type'];

    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    $allowed = ['jpg','jpeg','png','gif'];
    if(!in_array($ext, $allowed)){
        die("Upload failed");
    }

    if(strpos($type, 'image/') !== 0){
        die("Upload failed");
    }

    $data = file_get_contents($tmp);
    if(strpos($data, '<?php') === false){
        die("Upload failed");
    }

    if(is_file($tmp)){
        @unlink($tmp);
    }

    echo "Nice upload bypass. Flag: FLAG{HARD_UPLOAD}";
    exit;
}
?>
<form method="POST" enctype="multipart/form-data">
    <input type="file" name="file">
    <button>Upload</button>
</form>
