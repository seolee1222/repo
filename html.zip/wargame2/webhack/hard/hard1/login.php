<?php
session_start();

$data = json_decode(file_get_contents("users.json"), true);
$users = $data['users'];

$user = $_POST['user'] ?? '';
$pass = $_POST['pass'] ?? '';
$idOverride = $_POST['id'] ?? null;   // ← 공격자가 조작할 수 있는 값

$found = null;
foreach ($users as $u) {
    if ($u['username'] === $user && $u['password'] === $pass) {
        $found = $u;
        break;
    }
}

if ($found === null) {
    echo "로그인 실패";
    exit;
}

// ★ 취약한 부분: 클라이언트에서 보낸 id 값을 세션에 그대로 사용 가능
if ($idOverride !== null) {
    $_SESSION['id'] = (int)$idOverride;       // 공격자가 1로 바꾸면 세션 id = 1
} else {
    $_SESSION['id'] = (int)$found['id'];
}

// role은 여기선 안 씀. ID 기반 취약점 문제.
$_SESSION['username'] = $found['username'];

header("Location: profile.php?id=" . $found['id']);  // 기본은 자신의 id로 이동
exit;

