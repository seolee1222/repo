<?php
?>
<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>Hard - Broken Access Control 2</title>
  <link rel="stylesheet" href="../../../style.css">
</head>
<body class="Quiz-page">
  <header class="sub-header">
    <a href="../../webhack.html" class="back-btn">Back</a>
    <h1>Hard Level - Broken Access Control 2</h1>
  </header>

  <main style="padding: 20px; color:white;">
    <h2>로그인하여 프로필 페이지로 이동하세요</h2>
    <a href="index.php"> index.php에서 로그인할 수 있습니다.</a>
  </main>
	<section class="answer-box">
            <h2>정답</h2>
            <form id="answerForm">
                <input type="text" id="answer" name="answer" placeholder="FLAG{...}">
                <input type="submit" id="submit" value="Submit">
            </form>
        </section>

</body>
</html>

