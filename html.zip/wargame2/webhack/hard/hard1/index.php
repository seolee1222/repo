<?php session_start(); ?>
<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>Hard - Broken Access Control 2</title>
  <link rel="stylesheet" href="../../../style.css">
</head>
<body class="Quiz-page">
  <header class="sub-header">
    <a href="../../webhack.html" class="back-btn">Back</a>
    <h1>Hard Level - Broken Access Control 2</h1>
  </header>

  <main class="problem">
    <section class="problem-box">
      <h2>문제 설명</h2>
      <p>
        사용자 계정을 통해 로그인 후 자신의 프로필을 확인할 수 있습니다.<br>
        단, 일부 계정의 프로필은 관리자 전용으로 제한되어 있습니다.<br><br>
        일반 사용자(guest)로 로그인한 뒤, admin 프로필에 접근하여 FLAG를 획득하세요.
      </p>

      <p style="color:#ccc;font-size:0.9rem;">
        힌트: 클라이언트에서 넘기는 값을 믿는 코드는 위험할 수 있습니다.
      </p>

      <form method="POST" action="login.php">
        <input type="text" name="user" placeholder="username" required>
        <input type="password" name="pass" placeholder="password" required>

        <!-- 취약점: 클라이언트에서 세션 id를 조작할 수 있는 hidden 필드 -->
        <input type="hidden" name="id" value="2">

        <button type="submit">Login</button>
      </form>
    </section>
  </main>
</body>
</html>

