<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: index.php");
    exit;
}

$id = $_GET['id'] ?? '';

$data = json_decode(file_get_contents("users.json"), true);
$users = $data['users'];

// 요청한 id와 일치하는 유저 찾기 (느슨한 비교 사용)
$target = null;
foreach ($users as $u) {
    if ($u['id'] == $id) {         // == 사용 → "01" == 1 TRUE
        $target = $u;
        break;
    }
}

if ($target === null) {
    die("존재하지 않는 사용자입니다.");
}

// ★ 취약한 접근 제어 ★
// 세션에 저장된 id와 GET으로 넘어온 id를 느슨한 비교로만 확인.
// 세션 id를 1로 오염시키고, ?id=01 로 접근하면 admin 프로필을 볼 수 있게 됨.
if ($_SESSION['id'] != $id) {       // != , 느슨한 비교
    echo "<h2>🚫 다른 사용자의 프로필은 볼 수 없습니다.</h2>";
    exit;
}

echo "<h1>{$target['username']}의 프로필</h1>";

if ($target['role'] === 'admin') {
    echo "<p>{$target['flag']}</p>";
} else {
    echo "<p>일반 사용자입니다.</p>";
}
?>

