<?php

$style = '<body style="color: #f0f0f0; background-color: transparent; margin: 15px; font-family: sans-serif;">';

if (isset($_GET['ip'])) {
    $ip = $_GET['ip'];

    $blacklist1 = [
        'curl', 'wget', 'nc', 'netcat', 'bash', 'sh', 
        'python', 'perl', 'php', 'awk', 'sed'
    ];

    $blacklist2 = [
        '`' , '*', '?', 
        '{', '}', '\\', '\n', '\r', '\t', '%', 'IFS'
    ];
    
    $merged_blacklist = array_merge($blacklist1, $blacklist2);

    foreach ($merged_blacklist as $word) {
        if (stripos($ip, $word) !== false) {
		echo $style . "금지된 명령어가 포함되어 있습니다.</body>";
		exit;
        }
    }
    $cmd = "ping -c 1 " . $ip;
    shell_exec($cmd);

    echo $style . "핑 요청을 보냈습니다.</body>";

} else {
    echo $style . "IP 주소를 입력해주세요.</body>";
}
?>
