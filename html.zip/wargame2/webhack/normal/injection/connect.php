<?php
// connect.php
// DB 연결 정보를 필요에 맞게 수정하세요
$DB_HOST = 'localhost';
$DB_USER = 'user';
$DB_PASS = 'injectionpassword';
$DB_NAME = 'injection';

// MySQLi 연결
$link = mysqli_connect($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

// 연결 오류 처리
if (!$link) {
    // 개발용 오류 출력 (운영환경에서는 로깅으로 대체)
    die("데이터베이스 연결 실패: " . mysqli_connect_error());
}

// 문자셋 설정
mysqli_set_charset($link, 'utf8mb4');

// 이제 다른 파일에서 include("connect.php"); 하면 $link를 사용해서 쿼리 가능
?>
