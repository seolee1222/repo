<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

include("connect.php"); // DB 연결
$message = "";
$results = [];

if (isset($_POST['q'])) {
    $q = $_POST['q']; // 사용자의 입력을 그대로 받음 (취약점)

    $sql = "SELECT id, name, description FROM items WHERE id LIKE '%{$q}%'";

    $res = mysqli_query($link, $sql);

    if ($res) {
        while ($row = mysqli_fetch_assoc($res)) {
            $results[] = $row;
        }
        mysqli_free_result($res);
    } else {
        $message = "SQL 쿼리 오류: " . mysqli_error($link);
    }
    mysqli_close($link);
}
?>

<!doctype html>
<html lang="ko">
<head>
    <meta charset="utf-8">
    <title>검색 (SQLi 실습)</title>
    <style>
        body { 
            font-family: sans-serif; 
            font-size: 14px; 
            background: #121212; /* 검은색 배경 */
            color: #e0e0e0; /* 밝은 글자색 */
        }
        .wrap { 
            max-width: 600px; 
            margin: 60px auto; 
            padding: 20px; 
            background: #1e1e1e; /* 살짝 밝은 검정 */
            border-radius: 6px; 
            box-shadow: 0 2px 8px rgba(0,0,0,0.4); /* 다크모드용 그림자 */
            border: 1px solid #333; /* 테두리 */
        }
        input[type="text"] { 
            width: 80%; 
            padding: 10px; 
            margin-right: 8px; 
            background: #2c2c2c; /* 입력창 배경 */
            color: #e0e0e0; /* 입력창 글자색 */
            border: 1px solid #444;
            border-radius: 4px;
        }
        button { 
            padding: 10px 14px; 
            background: #007bff; /* 버튼색 (파랑) */
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background: #0056b3;
        }
        .result { 
            margin-top: 20px; 
        }
        .item { 
            padding: 8px; 
            border-bottom: 1px solid #333; /* 구분선 (어둡게) */
        }
        .msg { 
            color: #ff6b6b; /* 에러 메시지 (밝은 빨강) */
        }
    </style>
</head>
<body>
<div class="wrap">
    <h2>검색</h2>
    <?php if($message): ?>
        <p class="msg"><?php echo htmlspecialchars($message); ?></p>
    <?php endif; ?>

    <form method="post" action="">
        <input type="text" name="q" placeholder="검색어 입력 (id 또는 name 기준)" required value="<?php echo isset($_POST['q'])?htmlspecialchars($_POST['q']):''; ?>">
        <button type="submit">검색</button>
    </form>

    <div class="result">
    <?php if (!empty($results)): ?>
        <h3>검색 결과 (<?php echo count($results); ?>)</h3>
        
        <?php foreach ($results as $item): ?>
            <div class="item">
                <strong>ID:</strong> <?php echo htmlspecialchars($item['id']); ?><br>
                <strong>Name:</strong> <?php echo htmlspecialchars($item['name']); ?><br>
                <strong>Description:</strong> <?php echo htmlspecialchars($item['description']); ?>
            </div>
        <?php endforeach; ?>
        
    <?php elseif (isset($_POST['q'])): ?>
        <p>검색 결과가 없습니다.</p>
    <?php endif; ?>
    </div>
</div>
</body>
</html>
