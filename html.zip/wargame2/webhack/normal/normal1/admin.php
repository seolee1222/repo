<?php
// 워게임용 Host Header Injection 및 X-Forwarded-For 우회 테스트 페이지

$trusted_host = 'password1234.local';
$trusted_ip = '127.0.0.1';

$host = $_SERVER['HTTP_HOST'] ?? '';
$forwarded_for = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? '';
$remote_addr = $_SERVER['REMOTE_ADDR'] ?? '';

$is_host_valid = ($host === $trusted_host);
$is_ip_valid = ($forwarded_for === $trusted_ip);

if ($is_host_valid && $is_ip_valid) {
    echo "<!DOCTYPE html><html><head><title>Admin Access Granted</title></head><body>";
    echo "<h1>🎉 Admin Access Granted!</h1>";
    echo "<p>FLAG{Host Header Injection pass}</p>";
    echo "</body></html>";
} else {
    header('HTTP/1.1 403 Forbidden');
    echo "<!DOCTYPE html><html><head><title>403 Forbidden</title></head><body>";
    echo "<h1>🚫 Access Denied</h1>";
    echo "<p>You are not authorized to view this page.</p>";
    echo "</body></html>";
}
?>
