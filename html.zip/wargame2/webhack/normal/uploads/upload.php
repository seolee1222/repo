<?php
$uploadDir = __DIR__ . '/uploads/';
if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

$fileTmp = $_FILES['file']['tmp_name'];
$fileName = $_FILES['file']['name'];
$fileType = $_FILES['file']['type'];
// ----------------------------
// 1차 필터: 파일 시그니처 확인
// ----------------------------
$handle = fopen($fileTmp, 'rb');
$header = fread($handle, 8);
fclose($handle);

$mime = '';
if (substr($header, 0, 3) === "\xFF\xD8\xFF") $mime = 'image/jpeg';
elseif (substr($header, 0, 8) === "\x89PNG\r\n\x1A\n") $mime = 'image/png';
elseif (substr($header, 0, 6) === "GIF87a" || substr($header, 0, 6) === "GIF89a") $mime = 'image/gif';
else die("이미지 파일만 업로드 가능");

// ----------------------------
// 2차 필터: Content-Type 체크
// ----------------------------
// 업로드된 파일의 실제 MIME 타입 확인

// 시그니처에서 판단한 MIME와 실제 MIME가 다르면 차단
if ($mime !== $fileType) die(" 업로드 불가");

// ----------------------------
// 파일 이름 난수화 및 업로드
// ----------------------------
$ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
$newName = uniqid('img_', true) . '.' . $ext;

$imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', ''];

if (!in_array($ext, $imageExtensions)) {
    echo "Good job! flag:{koreaitacademy}<br>";
	
} else {
    echo "Hint: Try uploading a file that is not an image type";
}
?>
