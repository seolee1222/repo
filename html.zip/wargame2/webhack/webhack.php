<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Hacking</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body class="page-webhack">
    <header class="sub-header">
        <a href="../index.html" class="back-btn">BACK</a>
        <h1>Web Hacking</h1>
    </header>

    <main class="levels">
        <section class="level">
            <h2>Noob</h2>
            <ul>
                <li>
                    <a href="../webhack/noob/noob1/noob1.html" id="prob-noob1"
                       style="<?php echo file_exists('1.done') ? 'color:green;' : ''; ?>">noob1</a>
                </li>
                <li>
                    <a href="noob/noob2/noob2.html" id="prob-noob2"
                       style="<?php echo file_exists('2.done') ? 'color:green;' : ''; ?>">noob2</a>
                </li>
            </ul>
        </section>

        <section class="level">
            <h2>Easy</h2>
            <ul>
                <li>
                    <a href="../webhack/easy/easy1/easy1.html" id="prob-easy1"
                       style="<?php echo file_exists('3.done') ? 'color:green;' : ''; ?>">easy1</a>
                </li>
                <li>
                    <a href="../webhack/easy/easy2/index.html" id="prob-easy2"
                       style="<?php echo file_exists('4.done') ? 'color:green;' : ''; ?>">easy2</a>
                </li>
            </ul>
        </section>

        <section class="level">
            <h2>Normal</h2>
            <ul>
                <li>
                    <a href="../webhack/normal/normal1/normal.html" id="prob-normal1"
                       style="<?php echo file_exists('5.done') ? 'color:green;' : ''; ?>">normal1</a>
                </li>
                <li>
                    <a href="../webhack/normal/injection/index.html" id="prob-normal2"
                       style="<?php echo file_exists('6.done') ? 'color:green;' : ''; ?>">normal2</a>
                </li>
                <li>
                    <a href="../webhack/normal/uploads/index.html" id="prob-normal3"
                       style="<?php echo file_exists('7.done') ? 'color:green;' : ''; ?>">normal3</a>
                </li>
            </ul>
        </section>

        <section class="level">
            <h2>Hard</h2>
            <ul>
                <li>
                    <a href="../webhack/hard/hard1/hard1.php" id="prob-hard1"
                       style="<?php echo file_exists('8.done') ? 'color:green;' : ''; ?>">hard1</a>
                </li>
                <li>
                    <a href="../webhack/hard/hijacking/index.html" id="prob-hard2"
                       style="<?php echo file_exists('9.done') ? 'color:green;' : ''; ?>">hard2</a>
                </li>
                <li>
                    <a href="../webhack/hard/hard3/upload/index.php" id="prob-hard3"
                       style="<?php echo file_exists('10.done') ? 'color:green;' : ''; ?>">hard3</a>
                </li>
            </ul>
        </section>

        <section class="level">
            <h2>Very Hard</h2>
            <ul>
                <li>
                    <a href="../webhack/veryhard/ping/index.html" id="prob-veryhard"
                       style="<?php echo file_exists('11.done') ? 'color:green;' : ''; ?>">veryhard1</a>
                </li>
            </ul>
        </section>
    </main>
</body>
</html>

