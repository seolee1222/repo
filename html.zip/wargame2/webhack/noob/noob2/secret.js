const secretMessage = "FLAG{Drag_MOUSE_FLAG}";
const target = document.getElementById('secret-spot');

let mouseIsDown = false;

document.addEventListener('mousedown', () => {
    mouseIsDown = true;
});

document.addEventListener('mouseup', () => {
    mouseIsDown = false;
    target.textContent = "";
});

document.addEventListener('selectionchange', () => {

    if (!mouseIsDown) {
        return;
    }

    const selection = document.getSelection();
    let isIntersecting = false;

    if (selection.rangeCount > 0 && selection.anchorNode) {
        const range = selection.getRangeAt(0);
        if (range.intersectsNode(target)) {
            isIntersecting = true;
        }
    }

    if (isIntersecting) {
        target.textContent = secretMessage;
        target.style.color = "#cc0000";
    } else {
        target.textContent = "";
    }
});
