// 페이지 로드가 완료되면 스크립트 실행
document.addEventListener('DOMContentLoaded', function() {
    
    // 이 페이지가 '문제 목록' 페이지인지 확인하고 실행
    setupProblemListPage();

    // 이 페이지가 '개별 문제' 페이지인지 확인하고 실행
    setupProblemPage();
});

/**
 * [A] 문제 목록 페이지 (webhack.html)에서 실행될 함수
 * localStorage를 확인하여 해결한 문제에 'solved' 클래스를 적용합니다.
 */
function setupProblemListPage() {
    // '.levels' 클래스가 있는 페이지만 골라서 실행
    const levelListContainer = document.querySelector('.levels');
    if (!levelListContainer) {
        return; // 이 요소가 없으면, '문제 목록' 페이지가 아니므로 종료.
    }

    // 목록 페이지의 모든 문제 링크(<a>)를 찾습니다.
    const allProblemLinks = levelListContainer.querySelectorAll('.level li a');

    allProblemLinks.forEach(function(link) {
        const problemId = link.id; // 예: "prob-injection"
        
        // 링크에 id가 있고, localStorage에 'true'로 저장되어 있다면
        if (problemId && localStorage.getItem(problemId) === 'true') {
            link.classList.add('solved'); // .solved 클래스 추가
        }
    });
}

/**
 * [B] 개별 문제 풀이 페이지 (Noob2.html 등)에서 실행될 함수
 * 정답을 'check_answer.php' (서버)에 물어봅니다.
 */
function setupProblemPage() {
    // '#answerForm' 폼이 있는 페이지만 골라서 실행
    const answerForm = document.getElementById('answerForm');
    if (!answerForm) {
        return; // 이 요소가 없으면, '개별 문제' 페이지가 아니므로 종료.
    }

    // HTML의 data-* 속성에서 이 문제의 ID를 읽어옵니다.
    const PROBLEM_ID = answerForm.dataset.problemId;

    // 폼에 ID가 설정되지 않았으면 오류를 표시하고 종료
    if (!PROBLEM_ID) {
        console.error("Form에 'data-problem-id' 속성이 없습니다.");
        return;
    }

    // 폼 제출(submit) 이벤트 감지
    answerForm.addEventListener('submit', function(e) {
        // 1. 폼 제출 시 페이지가 새로고침되는 것을 막습니다.
        e.preventDefault(); 
        
        // 2. 사용자가 입력한 값을 가져옵니다.
        const userAnswer = document.getElementById('answer').value;

        // 3. 서버(check_answer.php)로 전송합니다.
        //    (script.js와 check_answer.php가 같은 폴더에 있다고 가정)
        fetch('/wargame2/check_answer.php', { 
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            // 문제 ID와 사용자 정답을 JSON으로 만들어 보냄
            body: JSON.stringify({
                problemId: PROBLEM_ID,
                answer: userAnswer
            })
        })
        .then(response => response.json()) // 서버의 응답(JSON)을 받음
        .then(data => {
            // data는 {success: true} 또는 {success: false}
            if (data.success) {
                // 4-1. 정답일 경우
                alert("정답입니다!");
                
                // 5. localStorage에 이 문제를 'true'로 저장합니다.
                localStorage.setItem(PROBLEM_ID, 'true');
                
                // 6. 1초 뒤에 '뒤로가기' 버튼의 주소로 자동 이동합니다.
                setTimeout(() => {
                    const backButton = document.querySelector('.back-btn');
                    if (backButton) {
                        window.location.href = backButton.href; 
                    } else {
                        window.history.back(); // 뒤로가기 버튼이 없으면 그냥 뒤로
                    }
                }, 1000);

            } else {
                // 4-2. 오답일 경우
                alert("오답입니다.");
            }
        })
        .catch(error => {
            // (check_answer.php 파일이 없거나 PHP 오류가 나면 여기로 옴)
            console.error('정답 확인 중 오류 발생:', error);
            alert("서버 오류가 발생했습니다.");
        });
    });
}
