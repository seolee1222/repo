document.addEventListener("DOMContentLoaded", () => {
    console.log("password1234 site loaded.");
});
