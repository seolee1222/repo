<?php
header('Content-Type: application/json');

// 1. script.js가 보낸 JSON 데이터를 받습니다.
// (보안을 위해 실제 운영 시에는 입력값 검증(sanitization)이 필요합니다.)
$data = json_decode(file_get_contents('php://input'), true);

// 2. 전송된 문제 ID와 사용자 정답을 변수에 저장
$problemId = $data['problemId'] ?? null;
$userAnswer = $data['answer'] ?? null;

// 3. [서버에만 저장되는 실제 정답지]
// (모든 문제의 정답을 여기에만 저장합니다)
$flagDatabase = [
    "prob-noob1" => "FLAG{Page Source Vuln}", // Noob1 정답
    "prob-noob2" => "FLAG{Drag_MOUSE_FLAG}", // Noob2 정답
    "prob-easy1" => "FLAG{E WORLD pass}",
    "prob-easy2" => "FLAG{EASY2_DONE}",
    "prob-normal1" => "FLAG{Host Header Injection pass}",
    "prob-normal2" => "FLAG{Injection_P@ssW0rd_FLAG}",
    "prob-normal3" => "koreaitacademy",
    "prob-hard1" => "FLAG{Broken Access Control Pass}",
    "prob-hard2" => "FLAG{S3SSi0N_H1JACKing_SUcce55!!}",
    "prob-hard3" => "FLAG{HARD_UPLOAD}",
    "prob-veryhard" => "FLAG{PIN@_SUC(ES$}",

    "pros-noob0" => "FLAG{NOOB_DONE}",
    "pros-noob1" => "flag{cat special characters}",
    "pros-noob2" => "ppaasswwoorrdd11223344",
    "pros-noob3" => "NoobIsSoEZ",
    "pros-easy1" => "flag{find file size}",
    "pros-easy2" => "FLAG{EASY1_DONE}",
    "pros-easy3" => "FLAG{SSH_ACCUESS_C@nnect}",
    "pros-normal" => "p@ssw0rd1234",
    "pros-hard" => "agdteegt"
    
];

$response = ['success' => false];

// 4. 정답 확인: ID가 정답지에 존재하고, 사용자가 보낸 답과 일치하는지 확인
if (isset($flagDatabase[$problemId]) && $flagDatabase[$problemId] === $userAnswer) {
    
    // 5. 정답이 일치하면 성공 신호를 보냄
    $response = ['success' => true];
}

// 6. script.js에게 JSON 신호({success: true} 또는 {success: false})를 보냄
echo json_encode($response);
?>
